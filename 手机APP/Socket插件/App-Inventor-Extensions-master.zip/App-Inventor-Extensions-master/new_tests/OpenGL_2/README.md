# test2

这是一个OpenGL的测试：视角控制

可以用上下滑动改变视角

aia丢失，Java源码也是反编译获得

![截图](README.IMG/MuMu20190806103601.png)
