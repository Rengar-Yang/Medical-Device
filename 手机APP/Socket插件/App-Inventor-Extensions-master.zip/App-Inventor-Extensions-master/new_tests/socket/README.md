# socket

wifi下的socket通信，我的csdn博客里有介绍

## MUMU模拟器多开测试

![MuMu20190806143220](README.IMG/MuMu20190806143220.png)
<center class="half"><img src="README.IMG/MuMu20190806143116.png" width="50%"/><img src="README.IMG/MuMu20190806143121.png" width="50%"/></center>
<center class="half"><img src="README.IMG/MuMu20190806143126.png" width="50%"/><img src="README.IMG/MuMu20190806143134.png" width="50%"/>
</center>


## 真机测试
<center class="half"><img src="README.IMG/20180824170507273.png" width="50%"/><img src="README.IMG/20180824170657547.png" width="50%"/>
</center>
