# test1

这个是OpenGL的一个简单测试：立方体旋转

应该就是csdn上那个忘截图的东西，更改了部分注释，才发现我几乎所有的Canvas都打错了

不要在意细节啦~~~

状态：aia丢失，只有Java源码和apk文件

![截图](README.IMG/MuMu20190806103055.png)
